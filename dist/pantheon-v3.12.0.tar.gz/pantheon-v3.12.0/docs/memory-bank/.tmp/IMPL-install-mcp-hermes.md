# IMPL-install-mcp-hermes
**Date:** 2026-05-29  **Status:** Awaiting Themis Review

## What Was Implemented

- `scripts/install-mcp.mjs` — Complete multi-platform MCP server installer for Pantheon

### Features
1. **Platform Detection:** Auto-detects OpenCode, VS Code, Cursor, Claude, and Windsurf config files
2. **MCP Definitions:** 6 MCPs defined (2 Tier 1 Essential + 4 Tier 2 Domain):
   - **Tier 1:** GitHub MCP (remote/OAuth), Context7 (npx)
   - **Tier 2:** Playwright (npx), PostgreSQL (npx + DATABASE_URL), Brave Search (npx + BRAVE_API_KEY), Docker (docker CLI)
3. **Platform Config Writers:** Each platform gets the correct JSON shape:
   - OpenCode → `opencode.json` `mcp` key
   - VS Code → `.vscode/mcp.json` `servers` key
   - Cursor → `.cursor/mcp.json` `mcpServers` key
   - Claude → `.mcp.json` or `~/.claude/settings.json` `mcpServers` key
   - Windsurf → `~/.codeium/windsurf/mcp_config.json` `mcpServers` key
4. **Safety:**
   - `--dry-run` mode previews without writing
   - Backup existing config before modifying
   - Don't overwrite existing MCP entries unless `--force`
5. **Validation:** Checks each MCP responds (npx resolve for npm packages, docker info for Docker)
6. **Interactive prompt** for Tier 2 MCPs when `--tier 2`
7. **CLI API:** `--platform`, `--tier`, `--mcp`, `--list`, `--dry-run`, `--force`, `--help`

## Tests/Verification
- ✅ `node --check scripts/install-mcp.mjs` — Syntax valid
- ✅ `--help` — Shows full usage documentation
- ✅ `--list` — Lists all 6 MCPs with tiers, env requirements
- ✅ `--dry-run --platform opencode` — Detects existing config, shows what would install
- ✅ `--dry-run --force` — Overwrites existing entries
- ✅ `--dry-run --platform vscode,cursor,claude --mcp github,context7,docker` — Multi-platform, multi-MCP
- ✅ `--mcp context7 --dry-run` — Skips existing entries correctly

## Notes for Themis
- File is at `scripts/install-mcp.mjs` with `#!/usr/bin/env node` shebang
- Uses ES modules (`import/export`)
- OpenCode-specific: uses `mcp` config key (not `mcpServers`) to match actual OpenCode format
- VS Code uses `servers` key in `.vscode/mcp.json`
- All platform config writers handle both local (stdio/command) and remote (http) MCP types
- No external npm dependencies — only uses Node.js stdlib
