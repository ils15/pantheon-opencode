# REVIEW-cross-platform-audit
**Date:** 2026-06-18  **Status:** APPROVED

## Verdict
**APPROVED** — All 9 proposed improvements are feasible for porting from oh-my-opencode-slim into Pantheon's .agent.md architecture. None are OpenCode-only blockers. Platform-specific degradations are documented.

## Issues
- CRITICAL: 0
- HIGH: 0
- MEDIUM: 2 (Aphrodite/Demeter have no body content — anti-stall checks need new prompt bodies; Copilot CLI cannot use any command-based features)
- LOW: 2 (Zeus already has comprehensive timeout/retry — enhancement, not new feature; Chiron has no body prompt)

## Summary Classification Table

| # | Improvement | Classification | Platform Limitations |
|---|-------------|---------------|---------------------|
| 1 | Stall Detection Protocol | ⚠️ PARTIAL | Copilot CLI: no Zeus agent. Cursor/Windsurf/Continue: no subagent delegation, stall detection degrades to "turns without output" heuristic. |
| 2 | Phase Reminder directives | ⚠️ PARTIAL | Copilot CLI: no Zeus, no phases. Continue.dev: no askUserQuestion tool, gates must be text output. |
| 3 | Delegate Retry rules | ⚠️ PARTIAL (already exists) | Copilot CLI: no delegation. Cursor/Windsurf/Continue: no subagents, retry applies only to @agent calls. |
| 4 | /reflect command | ⚠️ PARTIAL | Copilot CLI: no command system. Command is a prompt template — works wherever commands deploy. |
| 5 | /deepwork command | ⚠️ PARTIAL | Copilot CLI: no commands. Cursor/Windsurf/Continue: checkpointing requires file I/O, no session persistence. |
| 6 | /cancel-task command | ⚠️ PARTIAL (partial exists) | Copilot CLI: no commands. OpenCode: can abandon task_id. VS Code: no programmatic cancel. Rule-only platforms: no subagents to cancel. |
| 7 | Timeout/retry configs in routing.yml | ✅ CROSS-PLATFORM | None. routing.yml is a static data file. Already comprehensive. |
| 8 | Model fallback chains | ⚠️ PARTIAL | Copilot CLI: no Chiron, no skills. Cursor/Windsurf/Continue: Chiron is advisory rule, not runtime middleware. routing.yml data is universal. |
| 9 | Anti-stall self-checks in impl agents | ⚠️ PARTIAL | Copilot CLI: no impl agents. Aphrodite/Demeter currently have NO body content — biggest immediate need. |

## Key Platform Gotchas

1. **Cascade/Tier degradation**: Features requiring subagent delegation (task()) only work fully on VS Code and OpenCode. On Cursor/Windsurf/Continue/CLI, the same features degrade to advisory text or prompt templates.
2. **Continue.dev frontmatter stripping**: All agent metadata (tools, skills, handoffs, model) is stripped. Only body text survives. Behavioral directives MUST be self-contained in body content.
3. **Copilot CLI is terminal-only**: No agents, no commands, no skills, no subagents, no web fetch. Only .github/instructions/*.md is read. Pantheon orchestration is entirely unavailable — must pre-generate instructions.
4. **Skill loading varies by platform**: OpenCode/VS Code load skills natively. Cursor/Windsurf/Continue load them from .cursor/skills/, .windsurf/skills/, .continue/skills/ respectively. Copilot CLI does not load skills.

## Existing Platform-Gated Items (already in codebase)

| Item | Location | Gating |
|------|----------|--------|
| agentModeOverrides (OpenCode-only) | platform/opencode/adapter.json:72 | OpenCode primary/subagent distinction |
| handoffStrategy: "native" | platform/opencode/adapter.json:112 | OpenCode handoff buttons |
| ensureAgentTool: true | platform/opencode/adapter.json:113 | OpenCode task() tool guarantee |
| orchestration: true | opencode/claude adapters only | VS Code/Cursor/Windsurf/Continue/CLI have false |
| /subtask Tier 1 vs Tier 2 | commands/subtask.md:69-81 | Already documented per-platform |

## 🔍 Human Review Focus (requires your judgment)

1. **Copilot CLI support scope**: Should Pantheon invest ANY effort in Copilot CLI, or document it as "limited — pre-generated instructions only"? It has no agent system, making 8/9 improvements impossible there. Is pre-generating .github/instructions/*.md sufficient?

2. **Aphrodite/Demeter body content**: These two agents currently have ZERO body content (just YAML frontmatter). Before adding anti-stall self-checks (improvement #9), decide: should they get full prompt bodies like Hermes, or should anti-stall be a shared `instructions/anti-stall.instructions.md` applied to all implementers via `instructions:` frontmatter field?

3. **Chiron body prompt**: Chiron (47 lines, all frontmatter) has no operational body. Before model fallback chains can work (improvement #8), Chiron needs a body prompt. Should Chiron be a runtime middleware subagent (OpenCode/VS Code only) or a configuration advisor (cross-platform)?

## Artifact Protocol
- This REVIEW artifact is at: docs/memory-bank/.tmp/REVIEW-cross-platform-audit.md
- Ephemeral — deleted on sprint close
- Human validation of Review Focus items required before implementation proceeds
