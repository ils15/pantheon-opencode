# REVIEW-mcp-architecture
**Date:** 2026-05-29  **Status:** CONDITIONAL_APPROVAL

## Verdict
CONDITIONAL_APPROVAL — Proceed with Phase 1 (Playwright + Argus) immediately. Phases 2-5 require credential management and permission model decisions first.

## Issues
- CRITICAL: 3 / HIGH: 3 / MEDIUM: 2

### CRITICAL
1. **PostgreSQL MCP SQL injection risk** — MCP server must never accept raw SQL; expose narrow query API only
2. **Docker MCP container escape risk** — Deny `exec`, `--privileged`; image allowlist required
3. **Credential isolation** — Credentials must never appear in agent-readable context; MCP servers manage credentials internally

### HIGH
1. **Delegation-chain permission escalation** — Agent A (limited) → Agent B (MCP access) = Agent A gains MCP access. Requires agent-scoped MCP permissions.
2. **MCP credential management** — Where do PostgreSQL/Docker credentials live? If agents can read `.env`, MCP isolation is theater.
3. **Rate limiting** — PostgreSQL: 10/min, Docker: 5/min, Playwright: 20/min, GitHub: 30/min

### MEDIUM
1. **Playwright URL allowlist** — Agents must only navigate to localhost/staging domains
2. **Visual review loop iteration cap** — Max 3-5 iterations to prevent infinite loops

## Current State
- Only GitHub, Context7, Grep.app MCPs configured
- No Playwright, PostgreSQL, Docker, Brave Search, or OpenAPI MCPs exist yet
- Argus references `openBrowserPage`/`screenshotPage` (line 57-58) — partial design
- Aphrodite has crossed-out browser references (line 40-42) — planned but unavailable
- Permission model exists in opencode.json but has no MCP-level controls

## Recommended Implementation Order
| Phase | Scope | Gate |
|-------|-------|------|
| Phase 1 | Playwright MCP + Argus pipeline | Themis review + manual browser test |
| Phase 2 | PostgreSQL MCP (read-only, Demeter only) | SQL injection fuzzing + audit log verification |
| Phase 3 | Docker MCP (read-only, Prometheus only) | Container escape test + resource limit verification |
| Phase 4 | Agent template updates + delegation guide | Full integration test across all 17 agents |
| Phase 5 | Permission model extension (MCP-level controls) | Security audit with OWASP checklist |

## Security Recommendations
1. MCP servers expose narrow APIs, not raw tool access
2. Agent-scoped MCP permissions (not delegator-inherited)
3. Audit logging on MCP servers (not agents)
4. Dry-run before execute for destructive operations
5. Blast radius containment per agent scope

## Human Review Focus (requires your judgment)
1. **Credential management strategy** — Where will PostgreSQL/Docker credentials live?
2. **Delegation-chain policy** — Should Zeus delegate to agents with MCP access it doesn't have?
3. **MCP server hosting** — Sidecar (per-agent), shared service, or remote HTTP?

## Self-Reflection Quality Gate
| Category | Score |
|----------|-------|
| Correctness | 8/10 |
| Coverage | 8/10 |
| Security | 9/10 |
| Performance | 7/10 |
| Completeness | 8/10 |
| Clarity | 9/10 |
| **Average** | **8.2/10** |

## Confidence
**HIGH (8/10)** — Architectural direction is sound, risks are well-understood and mitigable. Deducted for: PostgreSQL/Docker MCPs don't exist yet, delegation-chain is novel, testing matrix is large.
