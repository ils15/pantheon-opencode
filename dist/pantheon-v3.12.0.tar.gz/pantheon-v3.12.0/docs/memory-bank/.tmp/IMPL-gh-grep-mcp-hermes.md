# IMPL-gh-grep-mcp-hermes
**Date:** 2026-06-18  **Status:** Awaiting Themis Review

## What Was Implemented
- `opencode.json` — Added `gh_grep` MCP server entry (type: local, command: npx -y @anthropic/grep-mcp-server, enabled: true) between exa and playwright in the mcp block, maintaining alphabetical order
- `agents/apollo.agent.md` — Added `grep_search_code` to Apollo's tools list and added gh_grep as third mcpServer (after context7 and exa) with tool `grep_search_code`
- `.mcp.json` — Added `gh_grep` server entry with command `npx` and args `["-y", "@anthropic/grep-mcp-server"]`

## Tests
- ✅ JSON validation (opencode.json): valid
- ✅ JSON validation (.mcp.json): valid
- ✅ YAML frontmatter structure preserved in apollo.agent.md
- ✅ No existing entries modified — only additions

## Notes for Themis
- Verify that `@anthropic/grep-mcp-server` is a valid npm package
- Confirm alphabetical ordering in opencode.json mcp block is correct
