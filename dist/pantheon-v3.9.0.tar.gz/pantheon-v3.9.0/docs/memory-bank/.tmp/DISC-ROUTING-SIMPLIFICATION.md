# DISC-ROUTING-SIMPLIFICATION

**Date:** 2026-05-21
**Status:** AWAITING_APPROVAL

## Question

Create a complete routing and simplification plan for Pantheon agents — well-documented canonical agents that the install script translates to different platforms.

---

## ☯️ Agora Synthesis

### 📋 Quick Summary

| | |
|---|---|
| **🤝 Consensus** | The canonical agent source → adapter → sync pipeline is sound, but routing logic is scattered across 6+ files, canonical bodies contain platform-specific cruft, and the install script conflates too many concerns |
| **⚡ Key Tension** | How much routing metadata to embed in canonical agent YAML frontmatter vs. maintain in a separate routing matrix |
| **🎯 Bottom Line** | Centralize routing into a single declarative `routing.yml`, strip canonical agents to pure domain content (no platform sections), split install.mjs into a sync-runtime + platform-writer, and derive all platform files from these two sources |

---

### 🧩 Per-Perspective Deep Dives

#### 🔧 Backend Architecture Perspective

The current architecture has an elegant core (canonical → adapter → sync) but the implementation has leaked concerns: routing lives in agent bodies, platform-specific sections are embedded in canonical files then regex-filtered out, and both sync-platforms.mjs and install.mjs have grown beyond their original scope. The fix is to separate routing into a declarative data file, use a pure-template approach (with Mustache or equivalent) for platform output instead of regex-based body transformation, and split install.mjs into a thin orchestrator that calls focused modules per platform.

| Dimension | Assessment |
|-----------|------------|
| **Recommendation** | Declarative `routing.yml` + template-based platform output + modular install script |
| **Trade-offs** | More files initially, but each file becomes simpler and independently testable |
| **Risks** | Over-engineering if routing never changes; but 18 agents × 7 platforms = 126 files, so automation pays off |
| **Confidence** | 🟢 High |

#### 🗄️ Information Architecture Perspective

Routing information is currently duplicated across AGENTS.md, agents/README.md, zeus.agent.md body, each canonical agent's `handoffs` and `agents` frontmatter, and the docs. A human (or AI) reading any one file gets only a partial picture. The fix is a single `routing.yml` that both humans and machines read: it defines all delegation paths, invocation contexts, model tier mappings, and handoff triggers. From this, we generate both human docs (markdown tables, mermaid diagrams) and machine configs (opencode.json agent sections, platform agent overrides). Canonical agents should contain only domain content — no "Copilot Workflow Notes" or platform-specific sections.

| Dimension | Assessment |
|-----------|------------|
| **Recommendation** | Centralized `routing.yml` + auto-generated routing docs + stripped canonical agents |
| **Trade-offs** | Adds indirection: routing changes mean editing YAML instead of markdown |
| **Risks** | YAML drift — if routing.yml is not the single source, it becomes stale. Must be enforced in CI |
| **Confidence** | 🟢 High |

#### 🎯 Strategic Planning Perspective

The ROADMAP (v3.5.0) already targets documentation consolidation and skill gap closure. Routing + canonical agent simplification fits perfectly as a v3.5 milestone. The risk of not doing this now is accumulating more agents (19th, 20th) without a clean routing foundation — each new agent adds N×6 files of maintenance burden. The strategic sequence is: (1) design routing.yml schema, (2) strip canonical agents, (3) update sync engine, (4) refactor install script, (5) auto-generate routing docs, (6) CI enforcement. Do this BEFORE v3.6+ themes.

| Dimension | Assessment |
|------------|------------|
| **Recommendation** | Execute as v3.5.0 sub-milestone — sequential phases, each with its own artifact and approval gate |
| **Trade-offs** | Delays v3.6 features, but builds maintainability foundation for all future work |
| **Risks** | Scope creep if routing.yml attempts to encode too much |
| **Confidence** | 🟢 High |

---

### ✅ Agreements (where 2+ perspectives converge)

- ✅ **Routing must be centralized** — All 3 perspectives agree that current routing is scattered across too many files. A single declarative source is needed.
- ✅ **Canonical agents must be stripped of platform-specific content** — Sections like "Copilot Workflow Notes", "VS Code Integration", "Agent Lifecycle Hooks" belong in platform adapters, not canonical definitions. The sync engine's `bodyFilters` regex approach is brittle.
- ✅ **Install script needs modularization** — install.mjs at 1278 lines handling 6+ platforms with inline JSON, file copying, and config merging is too large. Split per platform.
- ✅ **Sync engine is correct in concept but over-engineered** — The CAPABILITY_TAXONOMY, validateAdapterCoverage, validateBodyForExcludedTools are good, but the regex-based body transformations are fragile. Template-based approach would be more maintainable.
- ✅ **Forge model tiers are well-done — use as template** — The forge.json approach of tier→agent mapping is clean. The routing.yml should follow a similar declarative pattern.

---

### ⚡ Divergences

| Issue | Position A | Position B | Resolution |
|-------|------------|------------|------------|
| Where to store routing metadata | **Backend Arch**: In canonical agent frontmatter | **Info Arch**: In separate routing.yml | **Chose centralized routing.yml** — keeps canonical agents focused on domain behavior |
| Template vs. transform for sync | **Backend Arch**: Mustache template per platform | **Strategic**: Keep current engine, refactor filters | **Chose template-based approach** — zero-maintenance when canonical body changes |
| Routing documentation approach | **Info Arch**: Auto-generate from YAML | **Strategic**: Hand-write, YAML for machines | **Chose auto-generation** — humans should never hand-edit routing tables |

---

### 📋 Decision Log

| Decision | Chosen Option | Alternatives Rejected | Trade-off Accepted | Trigger to Revert |
|----------|---------------|----------------------|-------------------|-------------------|
| **Routing source of truth** | routing.yml centralized YAML | Frontmatter extension, hybrid, hand-written docs | Added indirection: routing changes edit YAML not markdown | If routing.yml becomes stale >3 months |
| **Canonical agent format** | Pure domain content only (no platform sections) | Keep current format with bodyFilters | Existing agents must be edited to remove platform sections | If platform count drops below 3 |
| **Sync engine approach** | Template-based per platform (Mustache/Handlebars) | Current regex transform engine | More files per platform initially | If template count exceeds agent count × 2 |
| **Install script architecture** | Modular install/<platform>.mjs + thin orchestrator | Monolithic install.mjs | More files, import structure | Not expected to revert |
| **Routing documentation** | Auto-generated from routing.yml via npm run generate-routing-docs | Hand-written routing tables | Build dependency on generation script | If generated docs are unreadable |

---

### 🏆 Recommendation

Execute routing centralization and canonical agent simplification as the **v3.5.0 "Routing & Rationalization" milestone**, structured in 5 sequential phases:

1. **Phase 0 — Schema Design:** Create `routing.yml` schema definition document. Define delegation paths, invocation contexts, model tier mappings, and handoff triggers. Validate against all 18 agents.
2. **Phase 1 — Canonical Strip:** Remove all platform-specific sections from `agents/*.agent.md`. Move "Copilot Workflow Notes", "VS Code Integration", "Agent Lifecycle Hooks" content to platform adapter documentation.
3. **Phase 2 — Template Sync:** Refactor `sync-platforms.mjs` to use template-based output (Mustache or plain JS template strings) per platform-adapter instead of regex body transformations.
4. **Phase 3 — Modular Install:** Split `install.mjs` into `install/index.mjs` (thin orchestrator) + per-platform modules (`install/opencode.mjs`, `install/claude.mjs`, etc.).
5. **Phase 4 — CI + Docs:** Add CI check that validates `routing.yml` → generated docs are in sync. Add `npm run generate-routing-docs` command that outputs markdown tables + mermaid diagrams.

| Dimension | Value |
|-----------|-------|
| **Confidence** | 🟢 **High** — all 3 perspectives converged on the core direction |
| **Next step** | Implement with Zeus — Athena should produce the routing.yml schema design first |

---

### 🚧 Decision Gate

**Status:** 🟡 AWAITING_APPROVAL

Choose:
- ✅ **APPROVE** — proceed with the 5-phase plan
- 🔄 **REQUEST CHANGES** — revise specific decisions
- 🗑️ **DISCARD** — abandon this direction
