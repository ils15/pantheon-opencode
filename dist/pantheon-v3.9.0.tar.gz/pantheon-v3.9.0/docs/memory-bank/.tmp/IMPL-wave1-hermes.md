# IMPL-wave1-hermes
**Date:** 2026-05-22  **Status:** Awaiting Themis Review

## What Was Implemented

### File Created
- `scripts/test-adapter-conformance.mjs` — Comprehensive adapter conformance test suite (695 lines)

### Test Categories Implemented

1. **Schema Conformance** (Category 1)
   - Validates all 6 platform `adapter.json` files for required fields (`name`, `displayName`, `version`, `outputDir`, `frontmatter`, `toolMap`)
   - Checks `frontmatter.include`/`exclude` fields exist in canonical agent frontmatter keys
   - Validates `toolMap` keys are valid canonical tool names
   - Detects conflicting tool mappings (same platform value from multiple canonical tools)
   - Validates `excludeTools` entries against combined canonical + taxonomy tool set
   - Validates `bodyFilters` reference valid action types with required sub-fields

2. **Agent Output Conformance** (Category 2)
   - Verifies all 17 canonical agents have generated files per platform
   - Validates file extensions match adapter config
   - For frontmatter-capable platforms: validates YAML frontmatter parses correctly with `js-yaml`
   - For non-frontmatter platforms (cline): verifies no `---` wrappers where `skipFrontmatter: true`
   - Output size sanity check: warns if generated size <5% or >150% of canonical
   - Checks required fields from `frontmatter.include` are present (only fails if field was in canonical original)
   - Checks no fields from `frontmatter.exclude` are present

3. **Tool Mapping Conformance** (Category 3)
   - Validates every tool in generated frontmatter is a valid mapped platform tool name
   - Detects excluded canonical tools leaked into generated output
   - Checks body for non-strikethrough references to excluded tools
   - Ensures all portable tools used by agents are either mapped or excluded
   - Validates `#tool:xxx` strikethrough for excluded tools

4. **Capability Mapping Conformance** (Category 4)
   - Validates all flag values are boolean
   - When `orchestration: true`: verifies `agent` tool is mapped in `toolMap`
   - When `approval: true`: verifies `vscode/askQuestions` is mapped

5. **Agent Mode Conformance** (Category 5)
   - Validates all 17 agents have mode assignments (opencode)
   - Checks mode values are `primary` or `subagent`
   - Counts mode distribution

### CLI Flags
- `--verbose`: Detailed pass/fail per check
- `--platform <name>`: Test a single platform
- `--json`: Write structured JSON results to `test-results/adapter-conformance.json`

## Tests
- ✅ **Manual verification**: All 6 platforms pass with 0 failures
- ✅ `--verbose` flag produces detailed output (2036 passes verified)
- ✅ `--platform opencode` tests single platform
- ✅ `--json` writes structured JSON report
- ✅ Unknown platform produces correct error (exit code 1)
- ✅ 2072 total checks across 6 platforms

## Notes for Themis
1. **False positive risk**: The strikethrough check for excluded tools in body text uses `content.includes()` which is case-sensitive — should be fine since canonical tool names are lowercase
2. **Portable tool check**: Only flags portable tools that are actually used by at least one canonical agent (avoids false positives for taxonomy-listed tools not in use)
3. **Output size ratio**: Uses 5% and 150% thresholds (these are generous to avoid false alarms)
