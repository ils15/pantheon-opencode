# REVIEW: Pantheon Agent System Configuration Consistency

**Date:** 2026-05-25
**Status:** NEEDS_REVISION

## Verdict
NEEDS_REVISION — No CRITICAL runtime vulnerabilities, but 5 MEDIUM documentation inconsistencies between opencode.json (runtime authority) and agent .md files.

## Issues
- HIGH: 1 (task: true in apollo/mnemosyne/argus .md but no task perm in opencode.json)
- MEDIUM: 3 (aphrodite temp 0.3 vs 0.5, themis pip * not documented in .md, 5-agent steps drift)
- LOW: 0

## Gate Status
❌ NOT APPROVED — Documentation drift across 6+ agents must be resolved before merge.

## Detailed Findings

### 1. EDIT Permissions: ALL CLEAR ✅
All 18 agents have perfectly matching edit permissions between opencode.json and .md frontmatter.

### 2. TASK Permission Gap: HIGH
apollo.md, mnemosyne.md, argus.md all declare `task: true` in their tools section. However:
- opencode.json omits task permission for all three
- routing.yml sets can_delegate: false for all three
- task_budget: 0 for all three
Fix: Remove `task: true` from these .md files OR add an explanatory comment.

### 3. BASH: themis pip *: MEDIUM
opencode.json themis bash includes `pip *: allow` but themis.md only lists `pip-audit *`. Mitigated by global `pip *: allow` in root permissions.

### 4. HANDOFF Targets: ALL CLEAR ✅
All 6 handoffs (echo→talos, gaia→athena, iris→mnemosyne, hephaestus→prometheus, chiron→prometheus, agora→mnemosyne) verified against routing.yml and opencode.json task permissions.

### 5. Temperature: aphrodite 0.3 vs 0.5: MEDIUM
opencode.json has 0.3, aphrodite.md has 0.5. Only temperature mismatch across all 18 agents.

### 6. Additional: Steps drift in 5 agents: MEDIUM
athena (12 vs 15), hermes (30 vs 20), aphrodite (30 vs 20), hephaestus (25 vs 20), mnemosyne (20 vs 10).

## Human Review Focus
1. Which is authoritative: opencode.json or .md files?
2. aphrodite temperature: 0.3 or 0.5?
3. Should themis have pip * or only pip-audit *?

After persisting, confirm with: docs/memory-bank/.tmp/REVIEW-agent-config-consistency.md
