# Active Context

> Priority file — agents read first. Keep current. Stale is worse than none.

## Current Focus
**v3.8.1 Released** ✅ — All items for this milestone are complete.

## What Changed

### v3.8.1 Release (2026-05-23)
- **XDG Base Directory compliance** — new `scripts/paths.py` module
- **Agora real multi-agent dispatch** with timeout protection
- **Step reductions** for multi-agent stages (zeus 30→20, agora 20→10)
- **Canonical tool name fix** — agent vs task naming aligned
- **THROUGHPUT_TPS dedup** — duplicate metric removed
- PR #14 merged (release/v3.8.1 → main)
- Release tagged: https://github.com/ils15/pantheon/releases/tag/v3.8.1

### Key Decisions
- XDG paths are now the standard for all Pantheon scripts (follows FreeDesktop.org spec)
- Agora timeout protection prevents hung subagent dispatches from blocking the council
- Step budgets reduced to reflect real-world usage patterns — zeus 30→20, agora 20→10

### Next
- Proceed with multi-platform conformance matrix work from the 30/60/90 plan

### Blockers
None

---

## What Changed (Session 2026-05-21)

### Phase 0 — routing.yml (NEW)
- Created `routing.yml` (1302 lines) as the canonical routing source
- Contains: 18 agents with roles/capabilities, 35 delegation rules, 27 handoffs, 21 routing matrix entries, 7 supported platforms
- Single source of truth for all routing decisions

### Phase 1 — Agent Strip
- Removed VS Code/Copilot-specific sections from 11 canonical agents (~132 lines total)
- Sections removed: `Copilot Workflow Notes`, `VS Code Integration`, `Cloud Delegation`, `#runSubagent` references
- 7 agents were already clean (agora, argus, chiron, echo, gaia, hephaestus, nyx)
- All 11 agents now verified clean — zero VS Code patterns remain

### Phase 2 — Sync Engine + Routing Integration
- **Stale bodyFilters removed** from all 6 platform adapters
- **zeus.agent.md** updated: `AGENTS.md` → `routing.yml` references (3 occurrences)
- **Sync engine enhanced**: Added `loadRoutingYml()`, `generateRoutingTable()`, `inject-routing` bodyFilter
- **Routing table auto-injected** into zeus for OpenCode and Claude platforms
- Full `npm run sync` verified: 18 agents × 6 platforms, 0 errors

### Phase 3 — Install Script Modular
- `install.mjs` went from 1278 lines → 108 lines (thin coordinator)
- Logic extracted into 7 modules under `scripts/install/`:
  - `shared.mjs` — shared utilities (copyFiles, writeIfChanged, syncDir, installSkills, etc.)
  - `opencode.mjs`, `claude.mjs`, `cursor.mjs`, `windsurf.mjs`, `continue.mjs`, `copilot.mjs`
- Dry-run verified, all syntax checks pass

### Phase 4 — Validation + CI + Docs
- **`scripts/validate-routing.mjs`**: 124 checks, all PASS
- **`scripts/generate-routing-docs.mjs`**: Auto-generates routing docs (199 lines)
- **CI**: Routing validation added to `.github/workflows/ci.yml`
- **npm scripts**: Added `validate` and `docs`

### v3.7.1
- Version bumped (was 3.7.0)
- PR #10 merged (release/v3.7.1 → main)
- CHANGELOG.md updated

## Key Decisions
- `routing.yml` is the canonical routing source — all routing decisions stem from it
- Canonical agents (`agents/*.agent.md`) are now platform-agnostic (no VS Code sections)
- Sync engine reads routing.yml and injects routing tables into platform-specific zeus files
- CI validates routing.yml consistency on every PR
- `validate-routing.mjs` checks: agent registry completeness, skill availability, handoff validity, routing matrix agent references, subagent delegation targets

## Next
- Platform agents need to be verified working in their respective environments (OpenCode, Claude Code, etc.)
- Consider adding pre-delegation validation hook for routing.yml compliance
- Monitor Talos usage for scope violations

## Blockers
None

---

## Session 2026-05-21 (cont.) — Permission & Dispatch Enforcement + Hooks Bridge

### What Changed

**Phase 1 — Permission Hygiene (R1, R6, R8)**
- Added explicit `edit: allow` to 9 implementer agents (hermes, aphrodite, demeter, prometheus, hephaestus, chiron, echo, talos, mnemosyne) in both `opencode.json` and `agents/*.agent.md`
- Fixed Athena description in `opencode.json` (removed "& agora" conflation)
- Fixed Gaia description to clarify read-only analysis scope
- Fixed CLAUDE.md — added missing Argus and Agora agents (now 18 total)
- Translated Portuguese→English in repo memory files (`conventions.md`, `stack.md`)
- Restructured ROADMAP.md — v3.5.0 now correctly shows Delivered vs Future items
- Merged SETUP.md into INSTALLATION.md (single source of truth)

**Phase 2 — Agora Self-Consistency (R7, R9)**
- Fixed Agora's "never dispatch" contradiction — now allows Mnemosyne delegation for DISC artifacts
- Fixed DISC artifact template (no longer claims "saved to..." — properly asks Mnemosyne)
- Synced `disable_model_invocation: true` for gaia, talos, argus in opencode.json

**Phase 3 — Talos Boundaries & Post-Condition Infrastructure (R3, R5)**
- Created `scripts/hooks/validate-talos-scope.sh` — PreToolUse hook enforcing ≤2 files, no schema/security changes
- Added PostToolUse formatting hooks (`format-multi-language.sh`) to all 8 implementer agents
- Enhanced `routing.yml` Talos delegation rules with pre/post conditions
- Enhanced `on-subagent-delegation-start.sh` with routing.yml target validation
- Enhanced `on-subagent-delegation-stop.sh` with post-condition reminders
- Created `scripts/hooks/validate-post-conditions.sh` — checks REVIEW artifacts exist

**Phase 4 — Hooks Bridge (Claude Code Compat)**
- Installed `opencode-hooks-plugin` npm package for Claude Code ↔ OpenCode hook compatibility
- Created `.claude/settings.json` with PreToolUse, PostToolUse, Stop hook definitions
- Updated `validate-talos-scope.sh` and `validate-post-conditions.sh` to use Claude Code stdin JSON protocol
- Removed dead `hooks:` blocks from agent.md files (not natively supported by OpenCode)

**Phase 5 — Agora Permission Hardening**
- Added `task: { mnemosyne: allow }` to Agora — can only delegate to Mnemosyne
- Lowered Agora `task_budget` from 10 → 3
- Added Agora to `adapter.json` agentModeOverrides

### Key Decisions
- Hooks bridge uses Claude Code format (`opencode-hooks-plugin`) instead of native OpenCode plugins — works across Claude Code + OpenCode with one config
- `opencode-hooks-plugin` reads `.claude/settings.json` — same hooks work on both platforms
- Agora's delegation is restricted to artifact persistence only — no indirect editing
- Dispatch validation is informative (log+warn) not blocking — allows stabilization period

### Next
- ~~Platform agents need to be verified working in their respective environments~~ ✅ Done as part of hooks bridge
- Consider adding pre-delegation validation hook for routing.yml compliance
- Monitor Talos usage for scope violations

### Blockers
None

---

## Session 2026-05-22 — Multi-Platform Optimization & Restructuring Plan (v2)

### Current Focus
**Shift from OpenCode-centric validation to cross-platform conformance** for Pantheon as a multi-agent, multi-platform framework.

### Why This Shift
- Pantheon runtime model is canonical-first (`agents/*.agent.md` + `routing.yml`) and adapter-driven (`platform/*/adapter.json`)
- A single-platform stabilization plan is insufficient and can hide regressions in Claude/Cursor/Cline/Continue/Windsurf/Copilot targets
- Quality gates must validate parity by platform, not just per repository

### Key Decisions
- Adopt **contract-first architecture**:
  - Canonical contract is authoritative (`agents/*.agent.md`, `routing.yml`, permission model, skills/commands metadata)
  - Platform adapters are transformation layers only
- Add **cross-platform conformance matrix** as release gate:
  - Platforms: OpenCode, Claude, Cursor, Cline, Continue, Windsurf, Copilot
  - Validate: agent loading, tool mapping, delegation/handoffs, permissions, skills/commands discovery, hook/fallback behavior
- Require **adapter conformance tests** in CI for each platform output
- Release criteria updated: no vNext release without matrix-green across supported platforms

### 30/60/90 Execution Outline

#### 0-30 days (Stability)
- Canonical contract freeze + schema checks
- Parity tests: canonical vs generated outputs
- CI matrix smoke tests per platform adapter
- Resolve known inconsistencies (e.g., routing and agent registry drift)

#### 31-60 days (Reliability)
- End-to-end orchestration tests across platforms
- Routing decision traceability/logging
- Hooks behavior validation and documented fallbacks where unsupported

#### 61-90 days (Scale)
- Cross-platform observability (latency/token/cost by agent and platform)
- Quality scoring and regression trend tracking
- Release hardening and migration documentation

### Suggested Ownership (Canonical Agents)
- `@athena`: contract and acceptance criteria
- `@themis`: conformance suite + quality gates
- `@prometheus`: CI matrix + automation
- `@nyx`: telemetry/observability
- `@mnemosyne`: memory bank + docs
- `@zeus`: orchestration and dependency sequencing

### Next
- Create platform conformance checklist and DoD
- Convert 30/60/90 plan into actionable task artifacts in `docs/memory-bank/_tasks/`
- Add CI matrix job definitions per platform adapter

### Blockers
None
